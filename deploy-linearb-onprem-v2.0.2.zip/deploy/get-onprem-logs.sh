#! /bin/bash
set -e

timestamp=$(date +%s)
onprem_services=$(docker ps -f "network=on-prem-network" --format '{{.Names}}')
ongoing_containers=$(docker ps -a -f "name=ongoing" --format '{{.Names}}')
onprem_logs_timestamp=onprem_logs_${timestamp}
onprem_logs_basedir=/tmp
onprem_logs_outputdir=${onprem_logs_basedir}/${onprem_logs_timestamp}
mkdir -p "${onprem_logs_outputdir}"
for ongoing_container in $ongoing_containers; do
  echo "logging ongoing container: ${ongoing_container}"
  docker logs $ongoing_container 2>&1 &>"${onprem_logs_outputdir}/${ongoing_container}_output.log"
done

service_since=10080m
for onprem_service in ${onprem_services}; do
  echo "logging service: ${onprem_service}"
  docker logs ${onprem_service} --since ${service_since} 2>&1 &>"${onprem_logs_outputdir}/${onprem_service}_output.log"
done

echo "getting docker info..."
docker info >"${onprem_logs_outputdir}/docker_info_${timestamp}"

onprem_logs_tarball=onprem_logs_${timestamp}.tar.gz
echo "tarballing onprem logs to ${onprem_logs_tarball}..."
cd ${onprem_logs_basedir}
tar czf "${onprem_logs_tarball}"  "${onprem_logs_timestamp}"
echo "removing temporary logs from ${onprem_logs_outputdir}..."
rm -rf "${onprem_logs_outputdir}"
cd - >/dev/null
echo "done, logs available at ${onprem_logs_basedir}/${onprem_logs_tarball}"
