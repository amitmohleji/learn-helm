#!/bin/bash

function escape_slashes(  ) {
  local input="$1"
  local output=""
  output="${input//\//\\/}"
  echo "$output"
}

function replace_text_in_file(  ) {
    old_text=$1
    new_text=$2
    file_path=$3
    old_text=$(escape_slashes "$old_text")
    new_text=$(escape_slashes "$new_text")
    new_content=$(sed 's/'$old_text'/'$new_text'/g' $file_path)
    echo "$new_content" > $file_path
}

function cut_string(  ) {
    full_string=$1
    string_to_cut=$2
    result="${full_string//$string_to_cut}"
    echo $result
}

function get_current_value(  ) {
    string_to_find=$1
    file_path=$2
    full_string=$(cat $file_path | grep $string_to_find  | head -n 1)
    result=$(cut_string $full_string $(escape_slashes $string_to_find))
    echo $result
}

######main##############
TAG=v2.0.2
LINEARB_SENSORS_IMAGE_VERSION=v0.20.128

echo "This wizard will guide you on upgrade existing LinearB agent docker-compose installation."
echo " "

#current installation path
read -r -p "Please provide full current installation path (e.g. /home/ubuntu/linearb/deploy ): " answer
if [ -z "$answer" ]
then
    echo "Empty answer. looking at the default path /home/ubuntu/linearb/deploy "
    deploy_path="/home/ubuntu/linearb/deploy"
elif ! [ -d "$answer" ]
then
    print_and_exit "$answer is not a valid directory."
else
    deploy_path=$answer
fi

if [ -f "${deploy_path}/docker-compose.yaml" ]
then
    echo "Found ${deploy_path}/docker-compose.yaml, path ${deploy_path} looks OK"
else
    echo "The path ${deploy_path}, does not have a docker-compose.yaml file. "
    echo "exiting..."
    exit 1
fi

#Tag
read -r -p "Please provide requested tag to install [for TAG - ${TAG} please hit enter] : " answer
if [ -z "$answer" ]
then
    echo "Installing tag - ${TAG}"
    tag=$TAG
else
    tag=$answer
fi


#get current local values:
sensors_image_version=$(grep -oP '(?<=image: linearb-on-prem.jfrog.io/sensors:).*' ${deploy_path}/docker-compose.yaml)
api_key=$(get_current_value "LINEARB_PUBLIC_API_KEY=" ${deploy_path}/.env  )
org_id=$(get_current_value "ORG_ID=" ${deploy_path}/.env)
dd_api_key=$(get_current_value  "DD_API_KEY=" ${deploy_path}/.env)

log_line=$(cat ${deploy_path}/scheduler/config.ini | grep ":/logs"  | head -n 1)
result=${log_line#*\"}
log_path=${result%%:*}

echo "new tag is: ${tag}"
echo "api_key is: ${api_key}"
echo "org_id is: ${org_id}"
echo "dd_api_key is: ${dd_api_key}"
echo "log path is: ${log_path}"
echo "sensors image version is: ${sensors_image_version}"
echo "updating files..."

#set timestamp
timestamp=$(date +%s)

#backup local-db
sudo cp ${deploy_path}/local-db/db.json ${deploy_path}/local-db/db.json_${timestamp}

#docker-compose
mv ${deploy_path}/docker-compose.yaml ${deploy_path}/docker-compose.yaml_${timestamp}
cp docker-compose.yaml.template ${deploy_path}/docker-compose.yaml
replace_text_in_file '${TAG}' "$tag" ${deploy_path}/docker-compose.yaml
replace_text_in_file '${LINEARB_SENSORS_IMAGE_VERSION}' "$LINEARB_SENSORS_IMAGE_VERSION" ${deploy_path}/docker-compose.yaml



#scheduler/config.ini
mv ${deploy_path}/scheduler/config.ini ${deploy_path}/scheduler/config.ini_${timestamp}
cp scheduler/config.ini ${deploy_path}/scheduler/config.ini
replace_text_in_file "/home/ubuntu/linearb/deploy/logs" "$log_path" "${deploy_path}/scheduler/config.ini"
replace_text_in_file "/home/ubuntu/linearb/deploy/.env" "${deploy_path}/.env" "${deploy_path}/scheduler/config.ini"
replace_text_in_file "ORG_ID=<ORG_ID>" "ORG_ID=${org_id}" " ${deploy_path}/scheduler/config.ini"
replace_text_in_file "agent-api:latest" "agent-api:${tag}" " ${deploy_path}/scheduler/config.ini"


#.env
mv ${deploy_path}/.env ${deploy_path}/.env_${timestamp}
cp .env_template ${deploy_path}/.env
replace_text_in_file "<ORG_ID>" "$org_id" "${deploy_path}/.env"
replace_text_in_file "v2.0.2" "$tag" "${deploy_path}/.env"
replace_text_in_file '${DD_API_KEY}' "$dd_api_key" "${deploy_path}/.env"
replace_text_in_file "<LINEARB_PUBLIC_API_KEY>" "$api_key" "${deploy_path}/.env"


#agent-cli.sh
mv ${deploy_path}/agent-cli.sh ${deploy_path}/agent-cli.sh_${timestamp}
cp agent-cli.sh ${deploy_path}/agent-cli.sh
replace_text_in_file "v2.0.2" "$tag" ${deploy_path}/agent-cli.sh


#README
cp  README.md ${deploy_path}/README.md
