from kubernetes import client as c, config
from time import sleep, time
from os import environ
from celery import Celery

import linpy_logger.load_logger as logging

from onprem_utils.rabbitmq import RABBIT_USERNAME, RABBIT_PASSWORD, RABBIT_SERVER

logger = logging.getLogger(__name__)
app = Celery('tasks', broker=f'amqp://{RABBIT_USERNAME}:{RABBIT_PASSWORD}@{RABBIT_SERVER}:5672//')

ONPREM_LINTA_IMAGE = environ.get('ONPREM_LINTA_IMAGE')
POD_NAMESPACE = 'linearb'
JOB_TIMEOUT = 1000
POD_GRACE_TIME = 30
POD_MONITOR_INTERVAL = 3


@app.task
def process_batch_job(message):
    print(message)
    try:
        logger.info(f'New message: {message}')
        manifest = get_pod_manifest(message)
        instantiate_and_monitor_pod(manifest)
    except Exception as e:
        logger.exception(f"An error occurred while processing message: {e}")


def manipulate_job_name(job_name):
    try:
        if len(job_name) > 63:
            logger.warning(f"job_name {job_name} exceeds Kubernetes pod name limit, trimming")
        return job_name.lower().replace("_", "-")[:63]
    except Exception as e:
        logger.exception(f"An error occurred while manipulating job name: {e}")
        raise e


def instantiate_and_monitor_pod(manifest: dict) -> dict:
    def get_pod(name: str):
        return api_client.read_namespaced_pod(name=name, namespace=POD_NAMESPACE)

    logger.info("Instantiating up with the following manifest: {}".format(manifest))
    config.load_incluster_config()
    api_client = c.CoreV1Api()
    api_client.create_namespaced_pod(namespace=POD_NAMESPACE, body=manifest)
    sleep(POD_GRACE_TIME)
    elapsed_time = 0
    pod_name = manifest['metadata']['name']
    pod_start_time = time()

    try:
        pod = get_pod(pod_name)
    except Exception as e:
        logger.exception(f"An error occurred while reading pod: {e}")
        return {"pod_name": pod_name, "elapsed_time": elapsed_time, "status": "Failed"}

    while pod.status.phase != "Succeeded" and elapsed_time < JOB_TIMEOUT:

        if pod.status.phase in ["Failed"]:
            logger.error(f"Job failed for {pod_name} with status: {pod.status.phase}")
            break

        sleep(POD_MONITOR_INTERVAL)
        elapsed_time = time() - pod_start_time
        pod = get_pod(pod_name)
        continue

    result = {
        "pod_name": pod_name,
        "elapsed_time": elapsed_time,
        "status": pod.status.phase
    }

    logger.info("Finished ongoing job for %s - %s" % (str(pod_name), result))

    return result


def get_pod_manifest(message) -> dict:
    pod_manifest = {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": manipulate_job_name(message['job_name'])
        },
        "spec": {
            "restartPolicy": "Never",
            "imagePullSecrets": [{"name": "regcred"}],
            "containers": [
                {
                    "name": manipulate_job_name(message['job_name']),
                    "image": ONPREM_LINTA_IMAGE,
                    "command": ["sh", "-c", "\"./scripts/startup.sh\""],
                    "envFrom": [
                        {
                            "configMapRef": {
                                "name": "charts-values",
                            }
                        }
                    ],
                    "env": message["environment"]
                }
            ]
        }
    }
    return pod_manifest
