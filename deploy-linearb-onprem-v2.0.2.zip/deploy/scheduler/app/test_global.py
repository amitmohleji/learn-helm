from tasks import manipulate_job_name


def test_answer():
    assert manipulate_job_name('Ongoing_123123123_r9938475') == 'ongoing-123123123-r9938475'
