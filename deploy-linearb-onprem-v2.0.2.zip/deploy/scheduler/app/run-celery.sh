#!/bin/bash

celery -A tasks worker --loglevel=INFO -c "${SCHEDULER_NUMBER_OF_CELERY_WORKERS}"
