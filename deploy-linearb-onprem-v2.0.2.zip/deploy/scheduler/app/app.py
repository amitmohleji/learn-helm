import sys
import pika
import json
from os import environ
from retry import retry

import linpy_logger.load_logger as logging

from onprem_utils.rabbitmq import connect_to_rabbitmq
from tasks import process_batch_job

RABBIT_QUEUE_NAME = environ.get('RABBIT_QUEUE_NAME', 'q-batch-jobs')
THIS_POD_NAMESPACE = 'linearb'
ONPREM_LINTA_IMAGE = environ.get('ONPREM_LINTA_IMAGE')

RETRY_TIME = 30

logger = logging.getLogger(__name__)

# Very simple config to avoid importing linpy* . TODO: Remove and use linpy-logger
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


@retry(pika.exceptions.AMQPConnectionError, delay=RETRY_TIME, jitter=(1, 3), tries=10)
def run() -> None:
    """
    Main loop to process pending jobs.

    :raises Exception: If there is an error connecting to RabbitMQ or processing pending jobs.
    :return: None
    """

    def callback(ch, method, properties, body):
        logger.info(f"Processing message on channel {ch} with body {body}")
        message = json.loads(body)
        process_batch_job.delay(message)
        logger.info("Finished processing batch job message")

    logger.info("Starting scheduler")
    try:
        with connect_to_rabbitmq() as connection:
            channel = connection.channel()
            logger.info("Initiated channel.")
            channel.confirm_delivery()
            channel.queue_declare(queue=RABBIT_QUEUE_NAME, durable=True)
            channel.basic_qos(prefetch_count=1)
            channel.basic_consume(queue=RABBIT_QUEUE_NAME, on_message_callback=callback, auto_ack=True)
            logger.info(f"Starting basic consume on queue {RABBIT_QUEUE_NAME}...")
            channel.start_consuming()

    except (KeyboardInterrupt, SystemExit):
        logger.info("Shutting down intentionally...")
        channel.stop_consuming()
    except pika.exceptions.AMQPConnectionError as e:
        logger.exception(f"Caught pika.exceptions.AMQPConnectionError: {e}")
        raise e
    except pika.exceptions.ConnectionClosedByBroker as e:
        logger.exception('Connection closed by broker')
        raise e
    except Exception as e:
        logger.exception(f"An error occurred: {e}")
        raise e


if __name__ == "__main__":
    run()
