### Manual build scheduler image and push to Artifactory

This image is responsible for scheduling linta jobs.

There are 2 components based on this image:

## scheduler
Reads messages from Rabbitmq q-batch-jobs and activates celery task for each.

## scheduler-worker
A Celery task that is being called by scheduler above per every message.
The task will create a linta pod per message that will process needed activities (according to the given message).


