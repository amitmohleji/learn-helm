#!/bin/bash

COMMAND="$*"
NETWORK="--network=on-prem-network"

if [[ "$COMMAND" == *"no-network"* ]]
then
  NETWORK=""
  COMMAND=${COMMAND#"no-network"}
fi


docker run $NETWORK -it \
--env-file .env \
-v $(pwd)/local-db:/app/local-db \
-v $(pwd)/docker-compose.yaml:/app/docker-compose.yaml \
-v /var/run/docker.sock:/var/run/docker.sock:ro \
-v $(pwd)/scheduler:/scheduler \
-v $(pwd)/.env:/app/.env    \
-e PLATFORM='docker-compose' \
linearb-on-prem.jfrog.io/agent-cli:v2.0.2 \
python agent-cli.py ${COMMAND}
