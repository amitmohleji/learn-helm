#!/bin/bash

function escape_slashes(  ) {
  local input="$1"
  local output=""
  output="${input//\//\\/}"
  echo "$output"
}

function replace_text_in_file(  ) {
    old_text=$1
    new_text=$2
    file_path=$3
    old_text=$(escape_slashes "$old_text")
    new_text=$(escape_slashes "$new_text")
    new_content=$(sed 's/'$old_text'/'$new_text'/g' $file_path)
    echo "$new_content" > $file_path
}

function print_and_exit() {
  echo $1
  exit 1
}

TAG=v2.0.2


DOCKER_REGISTRY_FOLDER="$HOME/.docker"
DOCKER_REGISTRY_FILE_NAME="config.json"
DOCKER_REGISTRY_FILE_PATH="${DOCKER_REGISTRY_FOLDER}/${DOCKER_REGISTRY_FILE_NAME}"


echo "This wizard will guide you on first installation of linearb agent based on docker-compose."
echo "The installation TAG is: $TAG"
echo " "

#check localdb
str=$(ls $(pwd))
if [[ $str == *"local-db"* ]]
then
    read -r -p  "local-db exists, would you like to delete it [y/n]?" answer
    if [ "$answer" == "y"  ]
    then
        echo "deleting local-db"
        echo " "
        rm -rf local-db
    else
        echo "Integration DB will be kept!"
        echo " "
    fi
else
    echo "local-db does not exist, will be created..."
    echo " "
fi

#Tag
#read -r -p "Please provide requested tag to install [default: $TAG] : " answer
#if [ -z "$answer" ]
#then
#    echo "Tag is $TAG"
#    tag=$TAG
#else
#    tag=$answer
#fi


#current installation path - as readme instructs running from current working dir
DEFAULT_DEPLOY_PATH="$PWD"
read -r -p "Please provide a full current installation path (e.g. ${DEFAULT_DEPLOY_PATH} ): " answer
if [ -z "$answer" ]
then
    echo "Empty answer. looking at the default path $DEFAULT_DEPLOY_PATH "
    deploy_path=$DEFAULT_DEPLOY_PATH
elif ! [ -d "$answer" ]
then
    print_and_exit "$answer is not a valid directory."
else
    deploy_path=$answer
fi


#log_path
default_log_path="$DEFAULT_DEPLOY_PATH/logs"
read -r -p "Please provide a logs path [default: ${default_log_path}]: " answer
if [ -z "$answer" ]
then
    echo "Empty answer. looking at the default path $default_log_path "
    log_path=${default_log_path}
elif ! [ -d "$answer" ]
then
    print_and_exit "$answer is not a valid directory."
else
    log_path=$answer
fi

#docker registry credential
read -r -p "Please provide a LinearB docker registry token: " answer
if [ -z "$answer" ]
then
    print_and_exit "docker registry token is empty"
else
    docker_token=$answer
fi

#org_id
org_id_valid_re='^[0-9]+$'
read -r -p "Please provide your organization id: " answer
if [ -z "$answer" ]
then
    print_and_exit "organization id is empty"
elif ! [[ $answer =~ $org_id_valid_re ]]
then
    print_and_exit "organization id is not a valid integer"
else
    org_id=$answer
fi


#api_key
read -r -p "Please provide your API key to LinearB: " answer
if [ -z "$answer" ]
then
    print_and_exit "API key id is empty."
else
    api_key=$answer
fi

#Datadog api key
read -r -p "Please provide a Datadog API key: " answer
if [ -z "$answer" ]
then
    echo "Datadog API key not provided. Setting an empty value."
    dd_api_key=""
else
    dd_api_key=$answer
fi


##update needed files
#docker registry
docker_conf_content=$(cat << EOF
{
    "auths": {
        "https://linearb-on-prem.jfrog.io": {
            "auth": "${docker_token}",
            "email": "onprem@linearb.io"
        }
    }
}
EOF
)
mkdir -p "$DOCKER_REGISTRY_FOLDER"
echo "$docker_conf_content" > $DOCKER_REGISTRY_FILE_PATH


#update scheduler/config.ini
replace_text_in_file "/home/ubuntu/linearb/deploy/logs" "$log_path" "scheduler/config.ini"
replace_text_in_file "/home/ubuntu/linearb/deploy/.env" "${deploy_path}/.env" "scheduler/config.ini"
replace_text_in_file "ORG_ID=<ORG_ID>" "ORG_ID=${org_id}" "scheduler/config.ini"
replace_text_in_file "agent-api:latest" "agent-api:${tag}" "scheduler/config.ini"

#.env
cp .env_template .env
replace_text_in_file "<ORG_ID>" "$org_id" ".env"
replace_text_in_file '${DD_API_KEY}' "$dd_api_key" ".env"
replace_text_in_file "<LINEARB_PUBLIC_API_KEY>" "$api_key" ".env"
replace_text_in_file "tagplaceholder" "$TAG" ".env" 

#agent-cli.sh
replace_text_in_file 'tagplaceholder' "$TAG" "agent-cli.sh"
