# Manual for setup a LinearB On-premise agent

This guide is intended for a LinearB Solution Architect


## OS requirements
- Ubuntu 20.04 LTS


## Hardware requirements

- min 32GB of RAM
- min 4 vCPUs
- min 1TB of free disk space available for:
  - docker daemon root dir
  - docker container logs
- CPU - x86_64 (Intel/AMD)

## Software requirements

- Linux based OS
- Docker engine version (docker CE and not docker.io, PLS follow https://docs.docker.com/engine/install/ubuntu/) >= 20.10.14
- docker-compose version >= 1.29.2
- jq


## Ports used

Make sure the following ports are open on the machine you install the agent:

| *Direction* | *Port* | *Purpose*              |
|-----------|------|----------------------|
| in        | 80   | Webhook receiver     |
| out       | 433  | Cloning a repository |


## Prerequisites

Before you begin, make sure you have the following from LinearB Principal Solution Architect:

- LinearB API Token 
- LinearB organization id
- LinearB admin account id
- DataDog API key (optional)

For populating an API token, run the following cURL :
```
curl -X POST http://<host>/api/v1/tokens/generate -H 'organization-id: <org_id>' -H 'account-id: <acc_id>' -H 'Content-Type: application/json' -d '{"label": "on-prem"}' | jq .
```

Save the key returned by this call for later use.

## Let's start

### Step 1.a - First time deployment only!

Create working dir on your machine to host the installation files.
e.g.:
```
mkdir ~/linearb 
mkdir -p ~/linearb/deploy/logs
cd ~/linearb
```
Place your deployment zip file (deploy-linearb-onprem-<version>.zip) in the above directory and unzip it.

```
unzip deploy-linearb-onprem-<version>.zip
```
This results with a deployment that resides at /home/ubuntu/linearb/deploy .
cd to your deploy folder
Run:
```
./deploy.sh
```
Answer the wizards questions.
Notice! A docker registry file will be created on ~/.docker/config.json



### Step 1.b - For upgrades only!
Create working dir on your machine that is different than the running folder you have created on the first time deployment.
e.g.:
```
mkdir /tmp/linearb 
cd /tmp/linearb
```
Place your deployment zip file (deploy-linearb-onprem-<version>.zip) in the above (temporary) directory and unzip it.

```
unzip deploy-linearb-onprem-<version>.zip
```
cd to your temp deploy folder
Run:
```
./upgrade.sh
```
Notice! The wizard will ask you to provide the current installed dir. Please provide a path without the "/" at the end. 
e.g. /home/ubuntu/linearb/deploy 


### Step 2 - Spinning up the on-prem agent

Run `docker-compose up -d` 


### Step 3 - Health Check
```
./agent-cli.sh health-checks
```
Result should be:

```
Docker containers status: OK
LinearB API connectivity status: OK
LinearB accepted webhooks: Failed
```
This is acceptable as basic services are running, and we have not setup any integrations or webhooks yet.

### Step 4 - Setup a new integration

Run the following command for create a new integration. Available values for `<provider>` are: `github`, `gitlab` or `bitbucket`. Now replace the `<PAT Token>` with the token you generated. More info about generating PAT token and the required scopes needed: https://linearb.helpdocs.io/article/qlzg38hn0b-connect-github-with-a-personal-access-token
Make sure you create a **personal access token (classic)** rathen than **fine-grained personal access token**. Fine grained would not work with the on-prem agent.  
Make sure to provide your Git instance URI: `--self-hosted-uri https://github.example.com`

```
./agent-cli.sh add-integration --provider <provider> --token <PAT Token> --self_hosted_uri <Self hosted Git URI> --account_id <Admin Account ID>
```

Response should look like this:
```
Integration created successfully. The Integration id is: <integration id>
```

Integration id should be a number. Save the Integration id for later use.


### Step 5 - Register Git repositories

For registering single repository, use the following `register-single-repository` command. Replace the `integration-id` with the value you got from step 5 and <Repo URL> with your repository URL:
```
./agent-cli.sh register-single-repository --integration_id <integration id> --repo_name <repo name> --git_org <git organization for github> --group <group for gitlab>
```

For registering multiple repositories, use the following `register-repositories` command. Replace the `integration-id` with the value you got from step 5:
```
./agent-cli.sh register-repositories --integration_id <integration id> --query_str <repo search string> --page_size <number of repo to fetch> --git_org <git organization for github> --group <group for gitlab> --order_by <last_activity_at, supported by gitlab>
```


### Step 6.a - Installing a GitHub Organization-Level Webhook to enable WorkerB

If you are running with Github onprem (enterprise), please follow the following document:

https://linearb.helpdocs.io/article/xhdjeehvtt-github-organization-level-webhook

IMPORTANT: Replace the URL with: `http://<on prem agent host>/hooks/<provider>?integration_id=<integration id>` and Leave the secret empty, we don't need that for on-prem mode.

For instance, if your agent is installed on EC2 with internal domain of `linearb-on-prem.internal`, and the integration id from step 4 is 9999,  the full URL should be `http://linearb-on-prem.internal/hooks/github?integration_id=9999`.

You can validate the status by viewing a V sign next to the webhook.

You may serve the webhook receiver behind a proxy. A healthcheck point is available at `http://<on prem agent host>/health` 

### Step 6.b - Installing a Gitlab Group-Level Webhook to enable WorkerB

If you are using Gitlab with groups, you should create a group level webhook to enable WorkerB notifications in a similar manner to step 6.a

The required events are Push Events, Tag push events, Comments, and Merge request events

Please consult with LinearB solution architect on which events 

### Step 7 - Import Git contributors

Importing all of your Git contributors to our system
```
./agent-cli.sh import-contributors --integration_id <Integration id> --repo_url <Repository URL including .git>
```

You can verify that the import went well by running the next command:
```
./agent-cli.sh list-contributors --integration_id <Integration id>
```




## Other useful commands


### List all integrations
```
./agent-cli.sh list-integrations
```

### Disable a specific repository
```
./agent-cli.sh disable-repository --integration_id <Integration id> --repo_name <repo name>
```

### Reset the on-premise environment.

Running this command will :
- Delete the local database including all integrations
- Reset LinearB API Token

```
./agent-cli.sh reset-environment
```


## Backup
On prem agent you may want to backup between agent upgrades or installtions includes:

* .env file: includes basic settings, including access tokens to LinearB API services.
* ./local-db/db.json : includes integration settings, among them is your org level personal access token.


## useful .env variables

ONGOING_CONCURRENT_PROCESSES => sets how many processes of ongoing will run concurrently.

DOCKER_CLEANUP_TIME_DELTA= => Sets how long a finished docker container is retained.




## Known cavaets
The on prem agent runs scheduled tasks which runs docker containers that fetch and process data from the configured integrations ocassionally.

Although the agent cleans up finished containers after a certain period, some basic logs are persisted at ~/linearb/deploy/logs (or elsewhere as specified in step 1 and 2). You may create a symlink to store it on another device or create a log rotate if necessary.

## Getting Logs capsule for additional support
Run the get-onprem-logs.sh script to gather logs  
```
./get-onprem-logs.sh
```
The script outputs the logs to /tmp/onprem_logs_<timestamp>.tar.gz

This logs capsule contains logs from the last 7 days or as much as the docker daemon log-opts allow, including the following:
* Incoming webhooks request log
* Outgoing request log to LinearB web service
* Internal services log
* Ongoing repository checks

In order to obtain support, have it sent to LinearB customer success technical contact. 